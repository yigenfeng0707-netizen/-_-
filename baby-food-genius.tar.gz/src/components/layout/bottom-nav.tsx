"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, BookOpen } from "lucide-react";
import { cn } from "@/utils/utils";
import { motion } from "framer-motion";

const tabs = [
  { href: "/", label: "生成辅食", icon: Home },
  { href: "/diary", label: "成长日记", icon: BookOpen },
];

export function BottomNav() {
  const pathname = usePathname();

  return (
    <nav
      className={cn(
        "fixed bottom-0 left-0 right-0 z-20",
        "bg-white/95 backdrop-blur-md border-t border-[#F0EBE5]",
        "pb-[env(safe-area-inset-bottom)] md:hidden"
      )}
    >
      <div className="flex items-center justify-around h-16">
        {tabs.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || (href !== "/" && pathname.startsWith(href));
          return (
            <Link
              key={href}
              href={href}
              className="flex flex-col items-center gap-0.5 flex-1 py-2 min-h-[44px] justify-center"
            >
              <motion.div
                whileTap={{ scale: 0.85 }}
                className="flex flex-col items-center gap-0.5"
              >
                <div
                  className={cn(
                    "relative flex items-center justify-center w-8 h-8 rounded-full transition-colors duration-150",
                    active && "bg-[#FF9F43]/15"
                  )}
                >
                  <Icon
                    size={20}
                    className={cn(
                      "transition-colors duration-150",
                      active ? "text-[#FF9F43]" : "text-[#A89B8F]"
                    )}
                  />
                  {active && (
                    <motion.div
                      layoutId="nav-dot"
                      className="absolute -bottom-1 w-1 h-1 rounded-full bg-[#FF9F43]"
                    />
                  )}
                </div>
                <span
                  className={cn(
                    "text-[10px] font-medium transition-colors duration-150",
                    active ? "text-[#FF9F43]" : "text-[#A89B8F]"
                  )}
                >
                  {label}
                </span>
              </motion.div>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
