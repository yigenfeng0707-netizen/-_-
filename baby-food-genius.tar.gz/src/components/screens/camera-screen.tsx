"use client";

import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { X, Camera, Upload, CheckCircle } from "lucide-react";
import { toast } from "sonner";

interface ScanResult {
  ingredients: string[];
  confidence?: string;
  note?: string;
  error?: string;
}

export function CameraScreen() {
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [selected, setSelected] = useState<string[]>([]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // 生成预览
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = (reader.result as string).split(",")[1];
      const preview = reader.result as string;
      setImagePreview(preview);
      setScanning(true);

      try {
        const res = await fetch("/api/ai/scan-ingredients", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ imageBase64: base64, mimeType: file.type }),
        });
        const data: ScanResult = await res.json();

        if (!res.ok) {
          setScanResult({ ingredients: [], error: data.error || "识别失败" });
          toast.error("识别失败，请换一张图片重试");
        } else {
          setScanResult(data);
          if (data.ingredients?.length > 0) {
            setSelected(data.ingredients);
            toast.success(`识别到 ${data.ingredients.length} 种食材`);
          } else {
            toast.warning("未识别到合适食材，请换一张更清晰的照片");
          }
        }
      } catch {
        setScanResult({ ingredients: [], error: "网络错误" });
        toast.error("识别失败，请检查网络后重试");
      } finally {
        setScanning(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleToggle = (item: string) => {
    setSelected((prev) =>
      prev.includes(item) ? prev.filter((x) => x !== item) : [...prev, item]
    );
  };

  const handleConfirm = () => {
    if (selected.length === 0) {
      toast.warning("请至少选择一种食材");
      return;
    }
    // 通过 localStorage 传递回首页
    const existing = JSON.parse(localStorage.getItem("babyProfile") || "{}");
    const merged = Array.from(new Set([...(existing.ingredients || []), ...selected]));
    localStorage.setItem("babyProfile", JSON.stringify({ ...existing, ingredients: merged }));
    router.back();
  };

  return (
    <div className="min-h-svh bg-stone-950 text-stone-100 flex flex-col p-4">
      {/* 头部 */}
      <div className="flex items-center justify-between border-b border-stone-800 pb-3">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2.5 h-10 rounded-full bg-[#4ECDC4]" />
          <div>
            <h3 className="font-extrabold text-sm text-stone-100">
              AI 智能冰格寻鲜
            </h3>
            <p className="text-[10px] text-stone-400">
              拍照识别冰箱食材，AI自动填充
            </p>
          </div>
        </div>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => router.back()}
          aria-label="关闭扫描"
          className="bg-stone-800 p-2 rounded-full border border-stone-700 text-stone-400 hover:text-white"
        >
          <X size={16} />
        </motion.button>
      </div>

      {/* 取景框 */}
      <div className="relative w-full h-64 border-4 border-dashed border-[#4ECDC4] rounded-3xl overflow-hidden bg-stone-950 flex items-center justify-center my-4">
        {/* 网格辅助线 */}
        <div className="absolute inset-4 pointer-events-none flex justify-between">
          <div className="w-[1px] bg-white/10 h-full" />
          <div className="w-[1px] bg-white/10 h-full" />
        </div>
        <div className="absolute inset-4 pointer-events-none flex flex-col justify-between">
          <div className="h-[1px] bg-white/10 w-full" />
          <div className="h-[1px] bg-white/10 w-full" />
        </div>

        {imagePreview ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={imagePreview}
            alt="上传的食材图片"
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="flex flex-col items-center gap-2 text-stone-500">
            <span className="text-4xl animate-bounce">❄️</span>
            <span className="text-[10px] font-mono tracking-widest">
              点击下方按钮上传冰箱照片
            </span>
          </div>
        )}

        {/* 扫描动画 */}
        {scanning && (
          <motion.div
            className="absolute left-0 right-0 h-8 bg-gradient-to-b from-[#4ECDC4]/20 to-transparent"
            animate={{ y: [0, 200, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
          />
        )}

        {/* 识别标注 */}
        {scanResult?.ingredients?.slice(0, 2).map((item, i) => (
          <motion.div
            key={item}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`absolute p-2 rounded-xl bg-black/85 border border-[#4ECDC4] flex items-center gap-1.5 z-10 ${
              i === 0 ? "top-[30%] left-[15%]" : "top-[55%] right-[10%]"
            }`}
          >
            <span className="text-[9px] font-bold text-stone-300">✓ {item}</span>
          </motion.div>
        ))}

        <span className="absolute text-[10px] text-stone-600 font-mono tracking-widest bottom-3">
          EAZO-LENS AUTO RECOGNITION ACTIVE
        </span>
      </div>

      {/* 上传按钮 */}
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileChange}
        className="hidden"
      />
      <motion.button
        whileTap={{ scale: 0.95 }}
        onClick={() => fileRef.current?.click()}
        disabled={scanning}
        className="w-full py-3 bg-stone-800 border border-stone-600 rounded-2xl text-stone-200 font-bold text-sm flex items-center justify-center gap-2 mb-4"
      >
        {scanning ? (
          <>
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-4 h-4 border-2 border-[#4ECDC4] border-t-transparent rounded-full"
            />
            <span>正在识别食材...</span>
          </>
        ) : (
          <>
            {imagePreview ? <Camera size={16} /> : <Upload size={16} />}
            <span>{imagePreview ? "重新拍照/上传" : "拍照或从相册选图"}</span>
          </>
        )}
      </motion.button>

      {/* 识别结果 */}
      <AnimatePresence>
        {scanResult?.ingredients && scanResult.ingredients.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-2.5 flex-grow"
          >
            <span className="text-[10px] font-black text-stone-400 uppercase tracking-widest block">
              🎉 识别到 {scanResult.ingredients.length} 款食材，请选择需要加入的：
            </span>
            <div className="grid grid-cols-3 gap-2">
              {scanResult.ingredients.map((item) => {
                const isSelected = selected.includes(item);
                return (
                  <motion.button
                    key={item}
                    whileTap={{ scale: 0.92 }}
                    onClick={() => handleToggle(item)}
                    className={`border rounded-xl p-2 flex flex-col items-center justify-center text-center relative transition-colors ${
                      isSelected
                        ? "bg-stone-700 border-[#4ECDC4]"
                        : "bg-stone-800 border-stone-700"
                    }`}
                  >
                    {isSelected && (
                      <CheckCircle
                        size={12}
                        className="absolute top-1 right-1 text-[#4ECDC4]"
                      />
                    )}
                    <span className="text-[10px] font-extrabold text-stone-200 mt-1">
                      {item}
                    </span>
                  </motion.button>
                );
              })}
            </div>
          </motion.div>
        )}

        {scanResult?.error && !scanResult.ingredients?.length && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-6 text-stone-500"
          >
            <p className="text-sm">识别失败，请换一张更清晰的照片</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 确认按钮 */}
      {scanResult?.ingredients && scanResult.ingredients.length > 0 && (
        <div className="pt-4 border-t border-stone-800 mt-3">
          <motion.button
            whileTap={{ scale: 0.96 }}
            onClick={handleConfirm}
            className="w-full py-3 bg-[#4ECDC4] hover:opacity-95 text-[#4A3B32] font-extrabold text-xs rounded-full border-2 border-[#4A3B32] shadow-[4px_4px_0px_0px_#4A3B32] flex items-center justify-center gap-1.5"
          >
            <span>✨ 锁定食材并注入配餐定制卡</span>
          </motion.button>
        </div>
      )}
    </div>
  );
}
