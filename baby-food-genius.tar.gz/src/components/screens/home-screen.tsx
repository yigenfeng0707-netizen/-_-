"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Camera, Plus, X } from "lucide-react";
import { toast } from "sonner";

const ALLERGIES = [
  { key: "milk", label: "牛奶", emoji: "🥛" },
  { key: "egg", label: "鸡蛋", emoji: "🥚" },
  { key: "peanut", label: "花生", emoji: "🥜" },
  { key: "seafood", label: "海鲜", emoji: "🍤" },
  { key: "wheat", label: "小麦", emoji: "🌾" },
  { key: "soy", label: "大豆", emoji: "🫘" },
];

const COMMON_INGREDIENTS = [
  "贝贝南瓜",
  "有机西兰花",
  "深海银鳕鱼",
  "胡萝卜",
  "番茄",
  "土豆",
  "菠菜",
  "苹果",
  "香蕉",
  "鸡胸肉",
  "猪肉",
  "米粥",
  "面条",
];

export function HomeScreen() {
  const router = useRouter();
  const [ageMonths, setAgeMonths] = useState(8);
  const [allergies, setAllergies] = useState<string[]>([]);
  const [ingredients, setIngredients] = useState<string[]>(["贝贝南瓜", "有机西兰花", "深海银鳕鱼"]);
  const [ingredientInput, setIngredientInput] = useState("");
  const [generating, setGenerating] = useState(false);

  // 从 localStorage 读取历史配置
  useEffect(() => {
    const stored = localStorage.getItem("babyProfile");
    if (stored) {
      try {
        const { ageMonths: a, allergies: al, ingredients: ing } = JSON.parse(stored);
        if (a) setAgeMonths(a);
        if (al) setAllergies(al);
        if (ing) setIngredients(ing);
      } catch {}
    }
  }, []);

  const handleToggleAllergy = (key: string) => {
    setAllergies((prev) =>
      prev.includes(key) ? prev.filter((x) => x !== key) : [...prev, key]
    );
  };

  const handleAddIngredient = () => {
    const trimmed = ingredientInput.trim();
    if (!trimmed) {
      toast.error("请输入食材名称");
      return;
    }
    if (ingredients.includes(trimmed)) {
      toast.warning("该食材已添加");
      return;
    }
    setIngredients((prev) => [...prev, trimmed]);
    setIngredientInput("");
  };

  const handleRemoveIngredient = (item: string) => {
    setIngredients((prev) => prev.filter((x) => x !== item));
  };

  const handleGenerate = async () => {
    if (allergies.length > 0 && ingredients.length === 0) {
      toast.warning("建议至少添加 1 种现有食材，帮助 AI 更好地配餐");
    }
    // 保存配置到 localStorage
    localStorage.setItem(
      "babyProfile",
      JSON.stringify({ ageMonths, allergies, ingredients })
    );
    setGenerating(true);
    // 模拟加载跳转
    router.push("/loading");
  };

  const handleOpenCamera = () => {
    router.push("/camera");
  };

  // 月龄标注
  let stageLabel = "初尝期";
  let stageDesc = "纯泥状，单一食材";
  if (ageMonths >= 7 && ageMonths <= 9) {
    stageLabel = "蠕咬期";
    stageDesc = "碎末糊或煮至极烂的面面";
  } else if (ageMonths >= 10 && ageMonths <= 12) {
    stageLabel = "压磨期";
    stageDesc = "小颗粒状，可添加软质肉类";
  } else if (ageMonths >= 13 && ageMonths <= 24) {
    stageLabel = "咀嚼期";
    stageDesc = "小块状，可添加普通主食";
  } else if (ageMonths >= 25) {
    stageLabel = "家庭小正餐";
    stageDesc = "接近成人饮食，少盐少糖";
  }

  return (
    <div className="min-h-svh bg-[#FAF7F2] flex flex-col">
      {/* 顶部标题卡 */}
      <div className="px-4 py-5">
        <div
          className="bg-[#FFEAA7] p-4 flex items-center justify-between relative overflow-hidden rounded-2xl border-2 border-[#4A3B32] shadow-[4px_4px_0px_0px_#4A3B32] [font-family:var(--font-fredoka)]"
        >
          <div className="space-y-1 z-10">
            <div className="bg-[#FF9F43] text-white text-[10px] font-black px-2.5 py-0.5 rounded-full inline-block border-2 border-[#4A3B32] shadow-[1px_1px_0px_0px_#4A3B32]">
              0-36个月定制
            </div>
            <h2 className="text-xl font-bold leading-none text-[#4A3B32]">
              今天宝宝吃什么？
            </h2>
            <p className="text-[11px] text-[#7A6B5D]">
              智能排除各大过敏选项，锁定今日冰箱生鲜
            </p>
          </div>
          <div aria-hidden="true" className="text-5xl transform rotate-6 animate-bounce">
            🍳
          </div>
        </div>
      </div>

      {/* 主内容区 */}
      <div className="px-4 space-y-6 flex-grow pb-4">
        {/* 1️⃣ 月龄选择器 */}
        <div className="bg-white p-5 space-y-4 rounded-2xl border-2 border-[#4A3B32] shadow-[4px_4px_0px_0px_#4A3B32]">
          <div className="flex items-center justify-between border-b-2 border-dashed border-[#4A3B32] pb-2.5">
            <span className="text-xs font-black tracking-wider text-[#7A6B5D]">
              1️⃣ 宝宝萌牙生长站
            </span>
            <span className="bg-[#FF9F43] text-white border-2 border-[#4A3B32] px-3 py-0.5 rounded-full text-xs font-bold shadow-[2px_2px_0px_0px_#4A3B32] flex items-center gap-1">
              <span>{ageMonths} 个月大</span>
              <span className="text-[10px] bg-white text-[#FF9F43] rounded-full px-1 py-0.5 scale-90">
                {stageLabel}
              </span>
            </span>
          </div>
          <div className="bg-[#FAF7F2] border-2 border-dashed border-[#4A3B32] rounded-2xl p-4 flex items-center gap-4 relative">
            <div className="w-14 h-14 rounded-full bg-[#FFEAA7] border-2 border-[#4A3B32] flex items-center justify-center text-2xl shadow-[2px_2px_0px_0px_#4A3B32] shrink-0">
              👶🦷
            </div>
            <div className="space-y-1">
              <div className="text-xs font-extrabold text-[#FF9F43]">
                咀嚼进阶 · {stageLabel}
              </div>
              <p className="text-[10.5px] text-[#7A6B5D] leading-snug">{stageDesc}</p>
            </div>
          </div>
          {/* 月龄滑块 */}
          <div className="space-y-2">
            <input
              type="range"
              min="0"
              max="36"
              step="1"
              value={ageMonths}
              onChange={(e) => setAgeMonths(Number(e.target.value))}
              className="w-full h-2.5 bg-stone-100 rounded-full border-2 border-[#4A3B32] appearance-none cursor-pointer
                [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-6 [&::-webkit-slider-thumb]:h-6 [&::-webkit-slider-thumb]:rounded-lg [&::-webkit-slider-thumb]:bg-[#FF9F43] [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-[#4A3B32] [&::-webkit-slider-thumb]:shadow-[2px_2px_0px_0px_#4A3B32]
                [&::-moz-range-thumb]:w-6 [&::-moz-range-thumb]:h-6 [&::-moz-range-thumb]:rounded-lg [&::-moz-range-thumb]:bg-[#FF9F43] [&::-moz-range-thumb]:border-2 [&::-moz-range-thumb]:border-[#4A3B32]"
            />
            <div className="flex justify-between text-[9px] font-extrabold text-[#7A6B5D] px-1">
              <span>0m 纯奶</span>
              <span className="text-[#FF9F43] font-black">🌟 {ageMonths}m</span>
              <span>36m 小正餐</span>
            </div>
          </div>
        </div>

        {/* 2️⃣ 过敏盾牌 */}
        <div className="bg-[#FAF7F2] p-5 space-y-3 rounded-2xl border-2 border-[#4A3B32] shadow-[4px_4px_0px_0px_#4A3B32]">
          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-xs font-black tracking-wider text-[#7A6B5D]">
                2️⃣ 避障安全盾牌
              </span>
              <p className="text-[10px] text-[#A89B8F]">
                被勾选的食材将由AI彻底排除
              </p>
            </div>
            <span aria-hidden="true" className="text-xl">🛡️</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {ALLERGIES.map(({ key, label, emoji }) => {
              const selected = allergies.includes(key);
              return (
                <motion.button
                  key={key}
                  whileTap={{ scale: 0.92 }}
                  onClick={() => handleToggleAllergy(key)}
                  aria-pressed={selected}
                  className={`border-2 border-[#4A3B32] font-extrabold p-2 rounded-2xl text-[11px] flex flex-col items-center justify-center gap-1.5 shadow-[2px_2px_0px_0px_#4A3B32] transition-colors ${
                    selected
                      ? "bg-[#FFB6C1] text-[#4A3B32]"
                      : "bg-white text-[#7A6B5D] opacity-80 hover:opacity-100"
                  }`}
                >
                  <span className="text-lg">{emoji}</span>
                  <span>{label} {selected && "(已拦截)"}</span>
                  <div
                    className={`w-10 h-1 rounded-full mt-0.5 ${
                      selected ? "bg-red-400" : "bg-stone-100"
                    }`}
                  />
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* 3️⃣ 冰箱食材 */}
        <div className="bg-white p-5 space-y-4 rounded-2xl border-2 border-[#4A3B32] shadow-[4px_4px_0px_0px_#4A3B32]">
          <div className="flex items-center justify-between border-b-2 border-dashed border-[#4A3B32] pb-2.5">
            <span className="text-xs font-black tracking-wider text-[#7A6B5D]">
              3️⃣ 检索冰箱剩余食材
            </span>
            <motion.button
              whileTap={{ scale: 0.92 }}
              onClick={handleOpenCamera}
              aria-label="扫描识别冰箱食材"
              className="text-[10px] font-black bg-[#FAF7F2] hover:opacity-95 p-1.5 rounded-lg border-2 border-[#4A3B32] shadow-[2px_2px_0px_0px_#4A3B32] flex items-center gap-1 text-[#4A3B32]"
            >
              <Camera size={14} strokeWidth={2.5} />
              <span>智能相机扫货</span>
            </motion.button>
          </div>
          <div className="flex gap-2">
            <input
              className="flex-grow bg-[#FAF7F2] border-2 border-[#4A3B32] rounded-xl px-3 py-1.5 text-xs text-[#4A3B32] focus:outline-none placeholder:text-[#A89B8F] font-extrabold"
              placeholder="输入手买/想塞入的生鲜食品"
              type="text"
              value={ingredientInput}
              onChange={(e) => setIngredientInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddIngredient()}
            />
            <motion.button
              whileTap={{ scale: 0.92 }}
              onClick={handleAddIngredient}
              aria-label="点我添加食材"
              className="p-2 bg-[#FFEAA7] rounded-xl border-2 border-[#4A3B32] flex items-center justify-center shrink-0 w-9 h-9 shadow-[2px_2px_0px_0px_#4A3B32]"
            >
              <Plus size={16} />
            </motion.button>
          </div>
          <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto py-0.5">
            {ingredients.map((item) => (
              <span
                key={item}
                className="inline-flex items-center gap-1 bg-white border-2 border-[#4A3B32] text-[11px] font-black py-1 px-2.5 rounded-full shadow-[2px_2px_0px_0px_#4A3B32]"
              >
                <span>{item}</span>
                <button
                  onClick={() => handleRemoveIngredient(item)}
                  aria-label={`移除${item}`}
                  className="hover:text-red-500 font-black ml-1 scale-110"
                >
                  <X size={14} />
                </button>
              </span>
            ))}
          </div>
          <p className="text-[9.5px] text-[#A89B8F] italic">
            📌 AI 将优先调度现有食材作为主粮配比
          </p>
        </div>
      </div>

      {/* 底部大按钮 */}
      <div className="p-4 bg-white border-t-2 border-[#4A3B32] shrink-0 pb-[calc(1rem+env(safe-area-inset-bottom))]">
        <motion.button
          whileTap={{ scale: 0.96 }}
          onClick={handleGenerate}
          disabled={generating}
          className="w-full py-4 text-base font-black text-white bg-[#FF9F43] rounded-full border-2 border-[#4A3B32] shadow-[4px_4px_0px_0px_#4A3B32] hover:opacity-95 disabled:opacity-70 flex items-center justify-center gap-2"
        >
          <span>👩‍🍳 一键熬制今日辅食大餐</span>
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="3"
            viewBox="0 0 24 24"
          >
            <path d="M5 12h14M12 5l7 7-7 7" />
          </svg>
        </motion.button>
      </div>
    </div>
  );
}
