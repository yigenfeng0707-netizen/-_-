"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { memory } from "@eazo/sdk";

interface DiaryEntry {
  id: string;
  date: string;
  ageMonths: number;
  plan?: Record<string, unknown>;
  note?: string;
  savedAt: number;
}

const REACTION_COLORS: Record<string, string> = {
  爱吃: "#FFEAA7",
  一般: "#FAF7F2",
  抗拒: "#FFB6C1",
};

export function DiaryScreen() {
  const [diary, setDiary] = useState<DiaryEntry[]>([]);
  const [noteInput, setNoteInput] = useState("");

  useEffect(() => {
    const raw = localStorage.getItem("recipeDiary");
    if (raw) {
      try {
        setDiary(JSON.parse(raw));
      } catch {}
    }
  }, []);

  const handleAddNote = () => {
    const trimmed = noteInput.trim();
    if (!trimmed) {
      toast.error("请输入记录内容");
      return;
    }
    const entry: DiaryEntry = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString("zh-CN"),
      ageMonths: JSON.parse(localStorage.getItem("babyProfile") || "{}")?.ageMonths || 8,
      note: trimmed,
      savedAt: Date.now(),
    };
    const updated = [entry, ...diary].slice(0, 50);
    setDiary(updated);
    localStorage.setItem("recipeDiary", JSON.stringify(updated));
    setNoteInput("");
    toast.success("记录已添加！");
    memory.reportAction({
      content: `宝宝辅食日记新增手动记录："${trimmed.slice(0, 50)}"`,
      event_type: "create",
      page: "diary",
      metadata: { type: "add_diary_note", note: trimmed },
    }).catch(() => {});
  };

  const handleDelete = (id: string) => {
    const updated = diary.filter((d) => d.id !== id);
    setDiary(updated);
    localStorage.setItem("recipeDiary", JSON.stringify(updated));
    toast.success("已删除该记录");
  };

  const handleClearAll = () => {
    if (!confirm("确定要清空全部日记吗？此操作不可恢复。")) return;
    setDiary([]);
    localStorage.setItem("recipeDiary", "[]");
    toast.success("已清空全部记录");
  };

  return (
    <div className="min-h-svh bg-[#FAF7F2] flex flex-col">
      <div className="px-4 py-5 space-y-6 flex-grow overflow-y-auto">
        {/* 顶部总览卡 */}
        <div className="bg-[#FFB6C1] p-4 flex items-center gap-3 relative overflow-hidden rounded-2xl border-2 border-[#4A3B32] shadow-[4px_4px_0px_0px_#4A3B32]">
          <motion.div
            className="text-3xl"
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 1.2, repeat: Infinity }}
          >
            🛡️
          </motion.div>
          <div className="space-y-0.5">
            <h4 className="font-extrabold text-[13px] text-[#4A3B32]">
              守护盾处于防卫态
            </h4>
            <p className="text-[10px] text-[#7A6B5D] leading-snug">
              已记录{" "}
              <strong>{diary.length} 条</strong>{" "}
              辅食喂养记录，帮助AI更懂宝宝。
            </p>
          </div>
        </div>

        {/* 快速手写入口 */}
        <div className="bg-white p-4 space-y-3 rounded-2xl border-2 border-[#4A3B32] shadow-[4px_4px_0px_0px_#4A3B32]">
          <span className="text-xs font-black tracking-wider text-[#7A6B5D]">
            ✍️ 添加宝贝喂餐小反应实录
          </span>
          <div className="flex gap-2">
            <input
              className="flex-grow bg-[#FAF7F2] border-2 border-[#4A3B32] rounded-xl px-3 py-1 text-xs text-[#4A3B32] focus:outline-none placeholder:text-[#A89B8F] font-extrabold"
              placeholder="例: 吃了菠菜碎面, 用餐正常无红疹, 胃口大开..."
              type="text"
              value={noteInput}
              onChange={(e) => setNoteInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddNote()}
            />
            <motion.button
              whileTap={{ scale: 0.92 }}
              onClick={handleAddNote}
              className="px-4 bg-[#FF9F43] text-white font-extrabold text-xs rounded-xl border-2 border-[#4A3B32] shadow-[2px_2px_0px_0px_#4A3B32] shrink-0"
            >
              速记
            </motion.button>
          </div>
        </div>

        {/* 历史时间轴 */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black tracking-wider text-[#7A6B5D]">
              📅 宝宝辅食手账历史时间轴
            </span>
            {diary.length > 0 && (
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={handleClearAll}
                className="text-[10px] font-bold text-stone-400 hover:text-red-500 underline"
              >
                清空全部
              </motion.button>
            )}
          </div>

          {diary.length === 0 ? (
            <div className="text-center py-12 text-[#A89B8F]">
              <div className="text-5xl mb-3">📖</div>
              <p className="text-sm">暂无记录，快去生成辅食或手动添加吧！</p>
            </div>
          ) : (
            <AnimatePresence>
              {diary.map((entry, index) => (
                <motion.div
                  key={entry.id}
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 16 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white p-4 space-y-3 rounded-2xl border-2 border-[#4A3B32] shadow-[4px_4px_0px_0px_#4A3B32]"
                >
                  <div className="flex items-center justify-between border-b border-dashed border-stone-200 pb-2">
                    <div className="flex items-center gap-1.5">
                      <span className="bg-[#FFEAA7] text-[10px] font-black border border-[#4A3B32] p-1 rounded-md px-1.5 leading-none">
                        {entry.date}
                      </span>
                      <div>
                        <span className="text-[9px] text-[#A89B8F] font-bold block">
                          {entry.ageMonths}个月
                        </span>
                        <h4 className="text-xs font-extrabold text-[#4A3B32]">
                          {entry.plan
                            ? (entry.plan as { meals?: { name: string }[] })?.meals?.[0]?.name || "食谱记录"
                            : "手动记录"}
                        </h4>
                      </div>
                    </div>
                    <motion.button
                      whileTap={{ scale: 0.9 }}
                      onClick={() => handleDelete(entry.id)}
                      aria-label="删除此记录"
                      className="text-stone-400 hover:text-red-500"
                    >
                      <Trash2 size={14} />
                    </motion.button>
                  </div>

                  {entry.note && (
                    <p className="text-xs text-[#7A6B5D] leading-relaxed">
                      {entry.note}
                    </p>
                  )}

                  {entry.plan && (entry.plan as { meals?: { type: string; name: string }[] })?.meals && (
                    <div className="flex flex-wrap gap-1">
                      {(entry.plan as { meals: { type: string; name: string }[] }).meals.map((m) => (
                        <span
                          key={m.type}
                          className="text-[10px] font-bold bg-[#FAF7F2] border border-[#E0D9D3] text-[#7A6B5D] px-2 py-0.5 rounded-full"
                        >
                          {m.type}: {m.name}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="text-[10px] text-[#A89B8F]">
                    记录于 {new Date(entry.savedAt).toLocaleString("zh-CN", { timeZone: "Asia/Shanghai" })}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          )}
        </div>
      </div>
    </div>
  );
}
