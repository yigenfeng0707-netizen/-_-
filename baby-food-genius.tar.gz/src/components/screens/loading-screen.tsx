"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { Check } from "lucide-react";
import { memory } from "@eazo/sdk";

const LOADING_STEPS = [
  "正在为宝宝搭配营养...",
  "正在检查过敏食材...",
  "正在适配月龄质地...",
  "正在结合冰箱食材配膳...",
  "精算营养平衡中...",
];

const FOOD_EMOJIS = ["🥬", "🎃", "🥩", "🥦", "🐟", "🍠"];

export function LoadingScreen() {
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [done, setDone] = useState(false);
  const [recipePlan, setRecipePlan] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    // 读取宝宝档案
    const profileRaw = localStorage.getItem("babyProfile");
    if (!profileRaw) {
      router.replace("/");
      return;
    }
    const profile = JSON.parse(profileRaw);

    let stepIndex = 0;
    const stepTimer = setInterval(() => {
      if (stepIndex < LOADING_STEPS.length - 1) {
        setCompletedSteps((prev) => [...prev, stepIndex]);
        stepIndex++;
        setCurrentStep(stepIndex);
      }
    }, 900);

    // 真实 AI 调用
    const fetchRecipe = async () => {
      try {
        const res = await fetch("/api/ai/generate-recipe", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ageMonths: profile.ageMonths || 8,
            allergies: (profile.allergies || []).map((k: string) => {
              const map: Record<string, string> = {
                milk: "牛奶",
                egg: "鸡蛋",
                peanut: "花生",
                seafood: "海鲜",
                wheat: "小麦",
                soy: "大豆",
              };
              return map[k] || k;
            }),
            dietPreference: profile.dietPreference || "普通",
            ingredients: profile.ingredients || [],
          }),
        });
        const data = await res.json();
        if (!res.ok) {
          setError(data.error || "生成失败，请重试");
        } else {
          setRecipePlan(data);
          localStorage.setItem("currentRecipePlan", JSON.stringify(data));
          // memory 埋点：生成辅食计划
          memory.reportAction({
            content: `宝宝辅食计划生成成功：${profile.ageMonths || 8}月龄，今日四餐已规划`,
            event_type: "create",
            page: "loading",
            metadata: {
              type: "generate_recipe",
              ageMonths: profile.ageMonths || 8,
              allergiesCount: (profile.allergies || []).length,
              ingredientsCount: (profile.ingredients || []).length,
            },
          }).catch(() => {});
        }
      } catch {
        setError("网络错误，请检查连接后重试");
      }
      clearInterval(stepTimer);
      setCompletedSteps(LOADING_STEPS.map((_, i) => i));
      setCurrentStep(LOADING_STEPS.length - 1);
      setDone(true);
    };

    fetchRecipe();
    return () => clearInterval(stepTimer);
  }, [router]);

  const handleReveal = () => {
    if (error) {
      router.replace("/");
      return;
    }
    router.push("/recipe");
  };

  return (
    <div className="min-h-svh bg-[#FAF7F2] flex flex-col items-center justify-between px-4 py-8">
      {/* 顶部装饰 */}
      <div className="w-16 h-1.5 bg-stone-300 rounded-full mx-auto" />

      {/* 主动画区 */}
      <div className="space-y-8 flex flex-col items-center flex-grow justify-center w-full max-w-sm">
        {/* 沸腾的锅 + 飘起的食材 */}
        <div className="relative w-36 h-36 flex items-center justify-center">
          {FOOD_EMOJIS.slice(0, 3).map((emoji, i) => (
            <motion.span
              key={emoji}
              className="absolute text-2xl"
              style={{ left: `${15 + i * 28}%` }}
              animate={{ y: [-8, -48, -8], opacity: [0.8, 0, 0.8] }}
              transition={{
                duration: 2.2,
                repeat: Infinity,
                delay: i * 0.5,
                ease: "easeInOut",
              }}
            >
              {emoji}
            </motion.span>
          ))}
          <motion.div
            className="text-8xl"
            animate={{ rotate: [-3, 3, -3], scale: [1, 1.04, 1] }}
            transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
          >
            🍲
          </motion.div>
        </div>

        {/* 状态提示器 */}
        <div className="space-y-3 w-full">
          <h3
            className="text-xl font-extrabold text-[#4A3B32] text-center [font-family:var(--font-fredoka)]"
          >
            辅食机熬制中...
          </h3>
          <div className="bg-white border-2 border-[#4A3B32] rounded-2xl p-4 shadow-[2px_2px_0px_0px_#4A3B32]">
            <ul className="space-y-2">
              {LOADING_STEPS.map((step, i) => {
                const isCompleted = completedSteps.includes(i);
                const isCurrent = currentStep === i && !isCompleted;
                return (
                  <motion.li
                    key={step}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.15 }}
                    className="flex items-center gap-2 text-[11px] font-bold"
                  >
                    {isCompleted ? (
                      <Check
                        size={14}
                        strokeWidth={3}
                        className="text-[#4ECDC4] shrink-0"
                      />
                    ) : isCurrent ? (
                      <motion.span
                        className="inline-block w-2.5 h-2.5 bg-[#FF9F43] rounded-full shrink-0"
                        animate={{ scale: [0.8, 1.3, 0.8] }}
                        transition={{ duration: 0.8, repeat: Infinity }}
                      />
                    ) : (
                      <span className="inline-block w-2.5 h-2.5 bg-stone-200 rounded-full shrink-0" />
                    )}
                    <span
                      className={
                        isCompleted
                          ? "text-[#4ECDC4]"
                          : isCurrent
                          ? "text-[#FF9F43]"
                          : "text-[#A89B8F]"
                      }
                    >
                      {step}
                    </span>
                  </motion.li>
                );
              })}
            </ul>
          </div>

          {error && (
            <AnimatePresence>
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-[#FFB6C1] border-2 border-[#4A3B32] rounded-2xl p-3 text-center text-sm text-[#4A3B32] font-bold"
              >
                {error}
              </motion.div>
            </AnimatePresence>
          )}
        </div>
      </div>

      {/* 底部按钮 */}
      <div className="w-full max-w-sm">
        <AnimatePresence>
          {done && (
            <motion.button
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              whileTap={{ scale: 0.96 }}
              onClick={handleReveal}
              className="w-full py-4 text-sm font-black bg-[#4ECDC4] hover:opacity-95 text-[#4A3B32] rounded-full border-2 border-[#4A3B32] shadow-[4px_4px_0px_0px_#4A3B32] flex items-center justify-center gap-1"
            >
              <span>{error ? "返回重试" : "🍲 熬汤完成！一键掀开锅盖"}</span>
              {!error && (
                <svg
                  className="w-4 h-4"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={3}
                  viewBox="0 0 24 24"
                >
                  <polyline points="9 18 15 12 9 6" />
                </svg>
              )}
            </motion.button>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
