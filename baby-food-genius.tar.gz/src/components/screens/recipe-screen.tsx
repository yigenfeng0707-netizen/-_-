"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, Copy, Heart, Share2, RefreshCw } from "lucide-react";
import { toast } from "sonner";

// ---- 类型定义 ----
interface MealNutrients {
  calories: number | string;
  protein: number | string;
  fat: number | string;
  carbs: number | string;
}
interface Meal {
  type: string;
  name: string;
  ingredients: string[];
  steps: string[];
  nutrients: MealNutrients;
  suitableAge?: string;
}
interface DailyNutrition {
  totalCalories: number;
  totalProtein: number;
  totalFat: number;
  totalCarbs: number;
  recommended: { calories: number; protein: number; fat: number; carbs: number };
}
interface RecipePlan {
  meals: Meal[];
  dailyNutrition: DailyNutrition;
  warnings: string[];
  advice: string;
}

// ---- 月龄动态营养指标 ----
interface NutrientSpec {
  key: string;           // 在 DailyNutrition 或估算值上的字段名（用于取值）
  label: string;         // 展示名称
  unit: string;
  color: string;
  getValue: (nu: DailyNutrition) => number;  // 从 dailyNutrition 取实测值
  recommended: number;   // 该月龄每日推荐摄入量
  priority: "key" | "normal"; // key=重点突出
  tip: string;           // 鼠标/展开时的科普说明
}

/** 按月龄分段返回动态营养指标列表（中国营养学会婴幼儿喂养指南） */
function getNutrientSpecs(ageMonths: number, nu: DailyNutrition): NutrientSpec[] {
  // 估算铁/锌/维生素D（基于总热量和蛋白质做合理比例估算，实际值由AI生成）
  const estimatedIron    = Math.round(nu.totalProtein * 0.55);   // 约 0.55mg/g蛋白质
  const estimatedZinc    = Math.round(nu.totalProtein * 0.25);   // 约 0.25mg/g蛋白质
  const estimatedVitD    = Math.round(nu.totalCalories * 0.022); // 约 0.022IU/kcal
  const estimatedCalcium = Math.round(nu.totalCalories * 0.38);  // 约 0.38mg/kcal

  if (ageMonths <= 6) {
    // 0-6 个月：以铁为核心重点
    return [
      {
        key: "iron", label: "铁", unit: "mg", color: "#FF9F43", priority: "key",
        getValue: () => estimatedIron,
        recommended: 0.3,
        tip: "0-6月宝宝铁需求低，母乳含量充足；辅食添加后需优先保证铁的来源",
      },
      {
        key: "calories", label: "热量", unit: "kcal", color: "#7A6B5D", priority: "normal",
        getValue: (n) => n.totalCalories,
        recommended: 550,
        tip: "0-6月每日总热量需求约550kcal，以母乳/配方奶为主",
      },
      {
        key: "protein", label: "蛋白质", unit: "g", color: "#4ECDC4", priority: "normal",
        getValue: (n) => n.totalProtein,
        recommended: 9,
        tip: "0-6月蛋白质主要来源于母乳，辅食期注意质量优于数量",
      },
    ];
  } else if (ageMonths <= 12) {
    // 7-12 个月：重点突出维生素D和锌
    return [
      {
        key: "vitD", label: "维生素D", unit: "IU", color: "#FF9F43", priority: "key",
        getValue: () => estimatedVitD,
        recommended: 400,
        tip: "7-12月每日需400IU维生素D，促进钙吸收、预防佝偻病，建议额外补充",
      },
      {
        key: "zinc", label: "锌", unit: "mg", color: "#4ECDC4", priority: "key",
        getValue: () => estimatedZinc,
        recommended: 3.5,
        tip: "7-12月每日需锌3.5mg，促进生长发育与免疫力，富含于肉末和豆类",
      },
      {
        key: "iron", label: "铁", unit: "mg", color: "#FFB6C1", priority: "normal",
        getValue: () => estimatedIron,
        recommended: 10,
        tip: "7-12月铁需求增至10mg/日，优先选择强化铁米粉和肉泥",
      },
      {
        key: "calories", label: "热量", unit: "kcal", color: "#7A6B5D", priority: "normal",
        getValue: (n) => n.totalCalories,
        recommended: 700,
        tip: "7-12月每日总热量约700kcal，辅食占比逐步提升",
      },
    ];
  } else {
    // 13-36 个月：全面均衡，蛋白质/钙/铁/锌四项并重
    return [
      {
        key: "protein", label: "蛋白质", unit: "g", color: "#FF9F43", priority: "key",
        getValue: (n) => n.totalProtein,
        recommended: ageMonths <= 24 ? 20 : 25,
        tip: "13月以上蛋白质需求约20-25g/日，鸡蛋、鱼肉、豆腐都是优质来源",
      },
      {
        key: "calcium", label: "钙", unit: "mg", color: "#4ECDC4", priority: "key",
        getValue: () => estimatedCalcium,
        recommended: 600,
        tip: "13-36月每日需钙600mg，强壮骨骼与牙齿，豆腐和绿叶菜含量丰富",
      },
      {
        key: "iron", label: "铁", unit: "mg", color: "#FFB6C1", priority: "key",
        getValue: () => estimatedIron,
        recommended: 9,
        tip: "13月以上铁需求约9mg/日，红肉和肝泥是最佳来源，搭配维C促吸收",
      },
      {
        key: "zinc", label: "锌", unit: "mg", color: "#FFEAA7", priority: "key",
        getValue: () => estimatedZinc,
        recommended: 4,
        tip: "13月以上锌需求约4mg/日，牡蛎、肉类、南瓜子含量高",
      },
      {
        key: "calories", label: "热量", unit: "kcal", color: "#A89B8F", priority: "normal",
        getValue: (n) => n.totalCalories,
        recommended: ageMonths <= 24 ? 1050 : 1300,
        tip: "13-36月每日热量需求约1050-1300kcal，随月龄增长逐步提升",
      },
    ];
  }
}

const MEAL_ICONS: Record<string, string> = {
  早餐: "🥣",
  午餐: "🍜",
  晚餐: "🍲",
  加餐: "🥑",
};
const MEAL_TIMES: Record<string, string> = {
  早餐: "07:30 晨光首餐",
  午餐: "11:30 能量午餐",
  晚餐: "18:00 温馨晚餐",
  加餐: "15:00 快乐午点",
};

// 营养进度条（支持重点突出样式）
function NutritionBar({
  label,
  value,
  recommended,
  color,
  unit,
  priority,
  tip,
}: {
  label: string;
  value: number;
  recommended: number;
  color: string;
  unit: string;
  priority: "key" | "normal";
  tip: string;
}) {
  const [showTip, setShowTip] = useState(false);
  const pct = recommended > 0 ? Math.min(Math.round((value / recommended) * 100), 100) : 0;
  const statusLabel =
    pct >= 90 ? "✓ 达标" : pct >= 60 ? "接近达标" : "偏低";
  const statusColor =
    pct >= 90 ? "#4ECDC4" : pct >= 60 ? "#FF9F43" : "#FFB6C1";

  return (
    <div
      className={`space-y-1.5 ${
        priority === "key"
          ? "bg-white rounded-2xl p-3 border-2 border-[#4A3B32] shadow-[2px_2px_0px_0px_#4A3B32]"
          : ""
      }`}
    >
      <div className="flex justify-between items-center text-[10px]">
        <div className="flex items-center gap-1">
          {priority === "key" && (
            <span className="text-[9px] font-black text-white bg-[#FF9F43] px-1.5 py-0.5 rounded-full border border-[#4A3B32] leading-none">
              重点
            </span>
          )}
          <span className={`font-bold ${priority === "key" ? "text-[12px] text-[#4A3B32]" : "text-[#7A6B5D]"}`}>
            {label}
          </span>
          <button
            onClick={() => setShowTip((v) => !v)}
            className="w-4 h-4 rounded-full border border-[#A89B8F] text-[9px] text-[#A89B8F] flex items-center justify-center leading-none shrink-0"
            aria-label={`查看${label}说明`}
          >
            ?
          </button>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[#7A6B5D]">
            {value}{unit} / {recommended}{unit}
          </span>
          <span
            className="font-black text-[10px] px-1.5 py-0.5 rounded-full border"
            style={{ color: statusColor, borderColor: statusColor, backgroundColor: statusColor + "22" }}
          >
            {statusLabel}
          </span>
        </div>
      </div>

      {/* 科普提示 */}
      <AnimatePresence>
        {showTip && (
          <motion.p
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="text-[10px] text-[#7A6B5D] bg-[#FAF7F2] rounded-lg px-2 py-1.5 border border-[#E0D9D3] overflow-hidden"
          >
            💡 {tip}
          </motion.p>
        )}
      </AnimatePresence>

      {/* 进度条 */}
      <div className={`w-full bg-[#F5F0EB] rounded-full border-2 border-[#4A3B32] p-0.5 ${priority === "key" ? "h-4" : "h-3"}`}>
        <motion.div
          className="h-full rounded-full"
          style={{ backgroundColor: color }}
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.9, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}

// 单餐卡片
function MealCard({ meal, mealIndex }: { meal: Meal; mealIndex: number }) {
  const [expanded, setExpanded] = useState(false);
  const [reaction, setReaction] = useState<string | null>(null);

  const icon = MEAL_ICONS[meal.type] || "🍽️";
  const time = MEAL_TIMES[meal.type] || meal.type;

  const handleReaction = (r: string) => {
    setReaction(r);
    toast.success(`已记录宝宝反馈：${r}`);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: mealIndex * 0.1 }}
      className="bg-white p-4 space-y-3 rounded-2xl border-2 border-[#4A3B32] shadow-[4px_4px_0px_0px_#4A3B32]"
    >
      <div className="flex items-center justify-between border-b border-dashed border-stone-200 pb-2">
        <div className="flex items-center gap-1.5">
          <span className="text-xl">{icon}</span>
          <div>
            <span className="text-[9px] text-[#A89B8F] font-bold block">{time}</span>
            <h4 className="text-[13px] font-black text-[#4A3B32]">{meal.name}</h4>
          </div>
        </div>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => setExpanded((v) => !v)}
          className="text-[10px] font-black text-[#FF9F43] border border-[#FF9F43] px-2 py-1 rounded-lg"
        >
          {expanded ? "收起" : "查看步骤"}
        </motion.button>
      </div>

      {/* 食材标签 */}
      <div className="flex flex-wrap gap-1">
        {meal.ingredients.map((ing) => (
          <span
            key={ing}
            className="text-[10px] font-bold bg-[#FAF7F2] border border-[#E0D9D3] text-[#7A6B5D] px-2 py-0.5 rounded-full"
          >
            {ing}
          </span>
        ))}
      </div>

      {/* 展开步骤 */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <ol className="space-y-1.5 pt-2">
              {meal.steps.map((step, i) => (
                <li key={i} className="flex gap-2 text-xs text-[#7A6B5D]">
                  <span className="shrink-0 w-5 h-5 rounded-full bg-[#FF9F43] text-white text-[10px] font-black flex items-center justify-center">
                    {i + 1}
                  </span>
                  <span>{step}</span>
                </li>
              ))}
            </ol>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 营养摘要 */}
      <div className="flex gap-2 text-[9px] font-bold">
        {[
          { label: "热量", val: meal.nutrients.calories, unit: "kcal", color: "#FF9F43" },
          { label: "蛋白质", val: meal.nutrients.protein, unit: "g", color: "#4ECDC4" },
          { label: "脂肪", val: meal.nutrients.fat, unit: "g", color: "#FFB6C1" },
          { label: "碳水", val: meal.nutrients.carbs, unit: "g", color: "#FFEAA7" },
        ].map(({ label, val, unit, color }) => (
          <div
            key={label}
            className="flex-1 text-center p-1.5 rounded-lg border border-stone-100"
            style={{ backgroundColor: color + "22" }}
          >
            <div className="font-black text-[#4A3B32]">{val}{unit}</div>
            <div className="text-[#A89B8F]">{label}</div>
          </div>
        ))}
      </div>

      {/* 反馈按钮 */}
      <div className="bg-[#FAF7F2] p-2 rounded-xl flex items-center justify-between gap-1.5 border border-dashed border-[#A89B8F]">
        <span className="text-[9.5px] font-extrabold text-[#7A6B5D]">用餐反馈：</span>
        <div className="flex items-center gap-1">
          {[
            { label: "😍 爱吃", value: "爱吃", activeBg: "#FFEAA7" },
            { label: "😐 一般", value: "一般", activeBg: "#FAF7F2" },
            { label: "🤢 抗拒", value: "抗拒", activeBg: "#FFB6C1" },
          ].map(({ label, value, activeBg }) => (
            <motion.button
              key={value}
              whileTap={{ scale: 0.9 }}
              onClick={() => handleReaction(value)}
              className={`text-[10px] font-black border-2 border-[#4A3B32] p-1 px-2 rounded-md transition-colors ${
                reaction === value ? "shadow-[1px_1px_0px_0px_#4A3B32]" : "bg-white"
              }`}
              style={{ backgroundColor: reaction === value ? activeBg : undefined }}
            >
              {label}
            </motion.button>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

export function RecipeScreen() {
  const router = useRouter();
  const [plan, setPlan] = useState<RecipePlan | null>(null);
  const [ageMonths, setAgeMonths] = useState(8);
  const [allergiesDisplay, setAllergiesDisplay] = useState<string[]>([]);

  const ALLERGY_LABELS: Record<string, string> = {
    milk: "牛奶", egg: "鸡蛋", peanut: "花生",
    seafood: "海鲜", wheat: "小麦", soy: "大豆",
  };

  useEffect(() => {
    const raw = localStorage.getItem("currentRecipePlan");
    if (!raw) { router.replace("/"); return; }
    try {
      setPlan(JSON.parse(raw));
    } catch { router.replace("/"); }

    const profileRaw = localStorage.getItem("babyProfile");
    if (profileRaw) {
      const p = JSON.parse(profileRaw);
      setAgeMonths(p.ageMonths || 8);
      setAllergiesDisplay((p.allergies || []).map((k: string) => ALLERGY_LABELS[k] || k));
    }
  }, [router]);

  const handleCopy = () => {
    if (!plan) return;
    const text = plan.meals.map((m) =>
      `【${m.type}】${m.name}\n食材：${m.ingredients.join("、")}\n步骤：${m.steps.join(" → ")}`
    ).join("\n\n");
    navigator.clipboard.writeText(text).then(() => toast.success("食谱已复制到剪贴板"));
  };

  const handleSaveToDiary = () => {
    if (!plan) return;
    const diary = JSON.parse(localStorage.getItem("recipeDiary") || "[]");
    const entry = {
      id: Date.now().toString(),
      date: new Date().toLocaleDateString("zh-CN"),
      ageMonths,
      plan,
      savedAt: Date.now(),
    };
    diary.unshift(entry);
    localStorage.setItem("recipeDiary", JSON.stringify(diary.slice(0, 50)));
    toast.success("已保存到成长日记！");
    router.push("/diary");
  };

  if (!plan) {
    return (
      <div className="min-h-svh flex items-center justify-center bg-[#FAF7F2]">
        <div className="space-y-2 text-center">
          {[0,1,2].map((i) => (
            <div key={i} className="h-4 w-48 mx-auto rounded skeleton-shimmer" />
          ))}
        </div>
      </div>
    );
  }

  const nu = plan.dailyNutrition;

  return (
    <div className="min-h-svh bg-[#FAF7F2] flex flex-col">
      <div className="px-4 py-5 space-y-5 flex-grow overflow-y-auto">
        {/* 顶部导航 */}
        <div className="flex items-center justify-between">
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={() => router.push("/")}
            className="flex items-center gap-1 text-xs font-black bg-white p-2 rounded-xl border-2 border-[#4A3B32] shadow-[2px_2px_0px_0px_#4A3B32]"
          >
            <ChevronLeft size={16} strokeWidth={3} />
            <span>回炉重配</span>
          </motion.button>
          <div className="text-right">
            <span className="text-[9px] uppercase tracking-widest text-[#A89B8F] block">
              EAZO 今日黄金食单
            </span>
            <h3 className="font-extrabold text-sm text-[#4A3B32]">
              {ageMonths}月龄宝宝专属排盘
            </h3>
          </div>
        </div>

        {/* 警示贴纸 */}
        {(allergiesDisplay.length > 0 || plan.warnings.length > 0) && (
          <div className="bg-[#FFEAA7] border-2 border-[#4A3B32] p-3.5 rounded-2xl relative shadow-[3px_3px_0px_0px_#4A3B32]">
            <div className="flex items-start gap-2 text-xs text-[#4A3B32] leading-relaxed">
              <span className="text-xl">💡</span>
              <div>
                <span className="font-extrabold text-[12px] block text-[#FF9F43]">
                  AI 避敏营养家温馨提示：
                </span>
                {allergiesDisplay.length > 0 && (
                  <span>
                    今日安排严格避开了 <strong>{allergiesDisplay.join("、")}</strong> 过敏原。
                  </span>
                )}
                {plan.warnings.map((w, i) => (
                  <span key={i} className="block mt-1 text-[11px] text-[#7A6B5D]">⚠️ {w}</span>
                ))}
                {plan.advice && (
                  <span className="block mt-1 text-[11px] text-[#4A3B32]">📝 {plan.advice}</span>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 四餐卡片 */}
        <div className="space-y-4">
          {plan.meals.map((meal, i) => (
            <MealCard key={i} meal={meal} mealIndex={i} />
          ))}
        </div>

        {/* 营养分析 - 月龄动态指标 */}
        <div className="bg-[#FAF7F2] p-4 space-y-4 rounded-2xl border-2 border-[#4A3B32] shadow-[4px_4px_0px_0px_#4A3B32]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black tracking-wider text-[#7A6B5D]">
              📊 今日膳食营养对比
            </span>
            <span className="text-[9px] text-[#A89B8F] bg-white border border-[#E0D9D3] px-2 py-0.5 rounded-full">
              {ageMonths}月龄推荐摄入量
            </span>
          </div>

          {/* 月龄动态指标说明 */}
          <div className="bg-white rounded-xl p-2.5 border border-dashed border-[#A89B8F]">
            <p className="text-[10px] text-[#7A6B5D] leading-relaxed">
              💡{" "}
              {ageMonths <= 6
                ? "0-6月重点关注铁含量，为后续辅食期打好基础"
                : ageMonths <= 12
                ? "7-12月重点关注维生素D与锌，促进骨骼发育与免疫力"
                : "13月以上关注蛋白质、钙、铁、锌全面均衡，支撑快速生长期"}
            </p>
          </div>

          {/* 动态营养指标列表 */}
          <div className="space-y-2.5">
            {getNutrientSpecs(ageMonths, nu).map((spec) => (
              <NutritionBar
                key={spec.key}
                label={spec.label}
                value={spec.getValue(nu)}
                recommended={spec.recommended}
                color={spec.color}
                unit={spec.unit}
                priority={spec.priority}
                tip={spec.tip}
              />
            ))}
          </div>

          {/* 底部营养等级评价 */}
          <div className="bg-white rounded-xl p-3 border-2 border-[#4A3B32] shadow-[2px_2px_0px_0px_#4A3B32]">
            <div className="flex items-center gap-2">
              <span className="text-lg">
                {getNutrientSpecs(ageMonths, nu).filter((s) =>
                  s.getValue(nu) >= s.recommended * 0.9
                ).length >= 3
                  ? "🌟"
                  : "💪"}
              </span>
              <div className="flex-1">
                <span className="text-[11px] font-black text-[#4A3B32] block">
                  {getNutrientSpecs(ageMonths, nu).filter((s) =>
                    s.getValue(nu) >= s.recommended * 0.9
                  ).length >= 3
                    ? "营养配比极优"
                    : "营养配比合理"}
                </span>
                <span className="text-[9px] text-[#7A6B5D]">
                  {plan.advice || "今日辅食符合该月龄营养需求，请按时喂养"}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 底部操作栏 */}
      <div className="p-4 bg-white border-t-2 border-[#4A3B32] shrink-0 grid grid-cols-4 gap-2 pb-[calc(1rem+env(safe-area-inset-bottom))]">
        <motion.button
          whileTap={{ scale: 0.92 }}
          onClick={handleCopy}
          className="py-2.5 bg-white border-2 border-[#4A3B32] text-[#4A3B32] text-[10px] font-black rounded-xl shadow-[2px_2px_0px_0px_#4A3B32] flex flex-col items-center justify-center gap-1"
        >
          <Copy size={14} />
          复制
        </motion.button>
        <motion.button
          whileTap={{ scale: 0.92 }}
          onClick={handleSaveToDiary}
          className="py-2.5 bg-[#FFB6C1] border-2 border-[#4A3B32] text-[#4A3B32] text-[10px] font-black rounded-xl shadow-[2px_2px_0px_0px_#4A3B32] flex flex-col items-center justify-center gap-1"
        >
          <Heart size={14} />
          存记
        </motion.button>
        <motion.button
          whileTap={{ scale: 0.92 }}
          onClick={() => router.push("/loading")}
          className="py-2.5 bg-[#FFEAA7] border-2 border-[#4A3B32] text-[#4A3B32] text-[10px] font-black rounded-xl shadow-[2px_2px_0px_0px_#4A3B32] flex flex-col items-center justify-center gap-1"
        >
          <RefreshCw size={14} />
          重做
        </motion.button>
        <motion.button
          whileTap={{ scale: 0.92 }}
          onClick={() => toast.info("分享功能开发中，可先使用复制按钮分享给家人")}
          className="py-2.5 bg-[#4ECDC4] border-2 border-[#4A3B32] text-[#4A3B32] text-[10px] font-black rounded-xl shadow-[2px_2px_0px_0px_#4A3B32] flex flex-col items-center justify-center gap-1"
        >
          <Share2 size={14} />
          分享
        </motion.button>
      </div>
    </div>
  );
}
