import { RecipeScreen } from "@/components/screens/recipe-screen";

export default function RecipePage() {
  return <RecipeScreen />;
}
