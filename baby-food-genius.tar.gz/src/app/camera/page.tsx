import { CameraScreen } from "@/components/screens/camera-screen";

export default function CameraPage() {
  return <CameraScreen />;
}
