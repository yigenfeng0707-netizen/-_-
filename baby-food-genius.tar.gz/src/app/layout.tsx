import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Fredoka, Noto_Sans_SC } from "next/font/google";
import { EazoProvider } from "@eazo/sdk/react";
import { cn } from "@/utils/utils";
import { Toaster } from "@/components/ui/sonner";
import { BottomNav } from "@/components/layout/bottom-nav";

const fredoka = Fredoka({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-fredoka",
});

const notoSansSC = Noto_Sans_SC({
  subsets: ["latin"],
  weight: ["400", "500", "700"],
  variable: "--font-noto",
});

const SITE_URL = process.env.VERCEL_URL
  ? `https://${process.env.VERCEL_URL}`
  : undefined;

export const metadata: Metadata = {
  ...(SITE_URL ? { metadataBase: new URL(SITE_URL) } : {}),
  title: "萌饭安安 — 宝宝智能辅食生成器",
  description: "面向0-36个月宝宝，AI一键避敏生成每日四餐辅食计划，拍照识别食材，精确克重",
  icons: { icon: "https://eazo.ai/favicon.ico" },
  openGraph: {
    type: "website",
    siteName: "萌饭安安",
    title: "萌饭安安 — 宝宝智能辅食生成器",
    description: "面向0-36个月宝宝，AI一键避敏生成每日四餐辅食计划",
    locale: "zh_CN",
  },
  twitter: {
    card: 'summary_large_image',
    title: "萌饭安安宝宝智能辅食",
    description: "萌饭安安是专为 0-36 个月宝宝家长设计的智能辅食规划助手。面对新手爸妈常见的\"今天吃什么\"\"宝宝会不会过敏\"\"营养够不够\"三大焦虑,萌饭安安提供一键式解决方案。输入宝宝月龄、过敏史、现有食材（支持拍照识别冰箱食材）后,AI 引擎会严格遵循《中国营养学会婴幼儿喂养指南》,自动生成一天三餐 + 加...",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="zh-CN"
      className={cn(
        "h-full antialiased",
        fredoka.variable,
        notoSansSC.variable
      )}
    >
      <body className="min-h-svh flex flex-col bg-[#FAF7F2]">
        <EazoProvider>
          {/* 主内容区 — 底部为导航留空间 */}
          <main className="flex-1 pb-[calc(4rem+env(safe-area-inset-bottom))] md:pb-0">
            {children}
          </main>
          {/* 底部标签栏 — 仅移动端 */}
          <BottomNav />
          <Toaster />
        </EazoProvider>
      </body>
    </html>
  );
}
