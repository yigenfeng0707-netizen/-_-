import { DiaryScreen } from "@/components/screens/diary-screen";

export default function DiaryPage() {
  return <DiaryScreen />;
}
