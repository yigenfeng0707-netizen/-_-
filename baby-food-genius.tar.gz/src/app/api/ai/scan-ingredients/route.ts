import { NextRequest } from "next/server";
import { ai } from "@eazo/sdk";

ai.configure({ privateKey: process.env.EAZO_PRIVATE_KEY! });

/**
 * POST /api/ai/scan-ingredients
 * 
 * 拍照识别食材（Vision）
 * Request body: { imageBase64: string, mimeType?: string }
 */
export async function POST(request: NextRequest) {
  try {
    const { imageBase64, mimeType = "image/jpeg" } = await request.json();

    if (!imageBase64) {
      return Response.json({ error: "缺少图片数据" }, { status: 400 });
    }

    const dataUrl = `data:${mimeType};base64,${imageBase64}`;

    const result = await ai.chat({
      model: "qwen.qwen3-vl-235b-a22b-instruct",
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `请识别这张图片（通常是冰箱或厨房食材的照片）中所有可见的食材、蔬菜、水果、肉类、主食等食物。

要求：
1. 只列出能确认看见的食材，不要猜测
2. 食材名称用中文，简洁通用（如"胡萝卜"而非"红萝卜"）
3. 忽略调味料、饮料、零食等不适合宝宝辅食的食物
4. 优先列出适合婴幼儿辅食的蔬菜、水果、肉类、主食类食材

请以 JSON 格式返回，格式如下：
{
  "ingredients": ["食材1", "食材2", "食材3"],
  "confidence": "high/medium/low",
  "note": "识别说明（可选）"
}

只返回 JSON，不加任何额外文字。`,
            },
            {
              type: "image_url",
              image_url: { url: dataUrl },
            },
          ],
        },
      ],
    });

    const rawText = result.choices[0].message.content || "";
    const cleanedText = rawText.replace(/^```json\n?/i, "").replace(/\n?```$/i, "").trim();

    let parsed;
    try {
      parsed = JSON.parse(cleanedText);
    } catch {
      return Response.json({ ingredients: [], error: "识别结果解析失败，请重试" }, { status: 500 });
    }

    return Response.json(parsed);
  } catch (error: unknown) {
    console.error("[scan-ingredients]", error);
    return Response.json(
      { ingredients: [], error: error instanceof Error ? error.message : "识别失败，请稍后重试" },
      { status: 500 }
    );
  }
}
