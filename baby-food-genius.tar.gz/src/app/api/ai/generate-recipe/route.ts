import { NextRequest } from "next/server";
import { ai } from "@eazo/sdk";

ai.configure({ privateKey: process.env.EAZO_PRIVATE_KEY! });

/**
 * POST /api/ai/generate-recipe
 * 
 * 生成宝宝辅食计划
 * Request body: {
 *   ageMonths: number,
 *   allergies: string[],
 *   dietPreference: string,
 *   ingredients: string[]
 * }
 */
export async function POST(request: NextRequest) {
  try {
    const { ageMonths, allergies, dietPreference, ingredients } = await request.json();

    // 月龄分段提示词
    let textureGuide = "";
    let portionRange = "";
    if (ageMonths >= 0 && ageMonths <= 6) {
      textureGuide = "纯泥状，单一食材，细腻滑润无颗粒";
      portionRange = "每餐 30-60 克";
    } else if (ageMonths >= 7 && ageMonths <= 9) {
      textureGuide = "细腻碎末状，可2-3种食材混合，无明显颗粒感";
      portionRange = "每餐 60-100 克";
    } else if (ageMonths >= 10 && ageMonths <= 12) {
      textureGuide = "小颗粒状，可添加软质肉类，略有咀嚼感";
      portionRange = "每餐 80-120 克";
    } else if (ageMonths >= 13 && ageMonths <= 24) {
      textureGuide = "小块状，可添加普通主食，稍软易咀嚼";
      portionRange = "每餐 100-150 克";
    } else {
      textureGuide = "接近成人饮食，少盐少糖，块状适中";
      portionRange = "每餐 120-180 克";
    }

    const systemPrompt = `你是婴幼儿营养专家，严格遵循《中国营养学会婴幼儿喂养指南》。

**任务**：为 ${ageMonths} 个月宝宝生成一天辅食计划（早餐、午餐、晚餐、加餐各1次）。

**严格约束**：
1. **绝对排除所有过敏食材**：${allergies.length > 0 ? allergies.join("、") : "无"}，以及其任何衍生物。
2. **优先100%使用现有食材**：${ingredients.length > 0 ? ingredients.join("、") : "自行搭配"}。
3. **质地要求**：${textureGuide}
4. **用量精确**：${portionRange}，每种食材精确到克（如"西兰花 15克"）
5. **制作步骤**：不超过5步，语言通俗易懂，适合新手家长。
6. **饮食偏好**：${dietPreference}

**输出格式（严格 JSON）**：
{
  "meals": [
    {
      "type": "早餐",
      "name": "菜名",
      "ingredients": ["食材1 克重", "食材2 克重"],
      "steps": ["步骤1", "步骤2"],
      "nutrients": { "calories": "热量值kcal", "protein": "蛋白质值g", "fat": "脂肪值g", "carbs": "碳水值g" },
      "suitableAge": "${ageMonths}月龄"
    }
  ],
  "dailyNutrition": {
    "totalCalories": 总热量数值,
    "totalProtein": 总蛋白质数值,
    "totalFat": 总脂肪数值,
    "totalCarbs": 总碳水数值,
    "recommended": { "calories": 该月龄推荐热量, "protein": 推荐蛋白质, "fat": 推荐脂肪, "carbs": 推荐碳水 }
  },
  "warnings": ["该月龄饮食禁忌1", "禁忌2"],
  "advice": "针对性营养补充建议（1-2句话）"
}

**注意**：
- 每餐需单独计算营养值，加总后填入 dailyNutrition。
- calories/protein/fat/carbs 都是数值类型，不带单位。
- 输出纯 JSON，无任何 markdown 标记或额外文字。`;

    const result = await ai.chat({
      model: "deepseek.v3.1",
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: `请为这位 ${ageMonths} 个月宝宝生成今天的辅食计划。`,
        },
      ],
      temperature: 0.7,
    });

    const rawText = result.choices[0].message.content || "";
    // 移除 markdown 代码块包裹（如果有）
    const cleanedText = rawText.replace(/^```json\n?/i, "").replace(/\n?```$/i, "").trim();

    let parsed;
    try {
      parsed = JSON.parse(cleanedText);
    } catch {
      // 如果解析失败，返回原始文本让前端处理
      return Response.json({ error: "AI 返回格式异常，请重试", raw: rawText }, { status: 500 });
    }

    return Response.json(parsed);
  } catch (error: unknown) {
    console.error("[generate-recipe]", error);
    return Response.json(
      { error: error instanceof Error ? error.message : "生成失败，请稍后重试" },
      { status: 500 }
    );
  }
}
