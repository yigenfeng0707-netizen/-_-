import { LoadingScreen } from "@/components/screens/loading-screen";

export default function LoadingPage() {
  return <LoadingScreen />;
}
