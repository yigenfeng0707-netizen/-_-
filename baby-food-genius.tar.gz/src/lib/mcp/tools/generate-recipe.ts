// src/lib/mcp/tools/generate-recipe.ts
// MCP tool: generate_recipe — 触发 AI 生成宝宝辅食计划

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";

export function registerGenerateRecipe(server: McpServer, _userId: string) {
  server.registerTool(
    "generate_recipe",
    {
      description: "为指定月龄的宝宝生成一日四餐辅食计划（严格遵循中国营养学会婴幼儿喂养指南）。",
      inputSchema: {
        ageMonths: z.number().int().min(0).max(36).describe("宝宝月龄（0-36个月）"),
        allergies: z
          .array(z.enum(["牛奶", "鸡蛋", "花生", "海鲜", "小麦", "大豆"]))
          .optional()
          .describe("过敏食材列表，这些食材将被完全排除"),
        ingredients: z
          .array(z.string())
          .optional()
          .describe("现有食材列表，AI 会优先使用"),
        dietPreference: z
          .enum(["普通", "素食", "无麸质"])
          .optional()
          .describe("饮食偏好"),
      },
    },
    async ({ ageMonths, allergies, ingredients, dietPreference }) => {
      try {
        // 调用内部 API（无 auth 要求的版本）
        const baseUrl = process.env.EAZO_PLATFORM_API_BASE
          ? `https://${process.env.VERCEL_URL || "localhost:3000"}`
          : "http://localhost:3000";

        const response = await fetch(`${baseUrl}/api/ai/generate-recipe`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ageMonths,
            allergies: allergies || [],
            dietPreference: dietPreference || "普通",
            ingredients: ingredients || [],
          }),
        });

        if (!response.ok) {
          const err = await response.json();
          return {
            isError: true,
            content: [{ type: "text" as const, text: `生成失败: ${err.error || "未知错误"}` }],
          };
        }

        const plan = await response.json();
        return {
          content: [
            {
              type: "text" as const,
              text: JSON.stringify(plan, null, 2),
            },
          ],
        };
      } catch (e) {
        return {
          isError: true,
          content: [{ type: "text" as const, text: `调用失败: ${e instanceof Error ? e.message : "未知错误"}` }],
        };
      }
    }
  );
}
