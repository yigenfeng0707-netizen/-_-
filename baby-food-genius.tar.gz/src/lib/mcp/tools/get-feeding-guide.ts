// src/lib/mcp/tools/get-feeding-guide.ts
// MCP tool: get_feeding_guide — 获取指定月龄的喂养指南

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";

const FEEDING_GUIDE: Record<string, { stage: string; texture: string; portionRange: string; prohibited: string[]; tips: string }> = {
  "0-6": {
    stage: "纯泥期",
    texture: "纯泥状，单一食材，细腻滑润无颗粒",
    portionRange: "每餐 30-60 克",
    prohibited: ["蜂蜜", "盐", "糖", "牛奶", "坚果", "海鲜", "鸡蛋"],
    tips: "以纯母乳或配方奶为主，6 月龄开始逐步引入辅食。",
  },
  "7-9": {
    stage: "蠕咬期",
    texture: "细腻碎末状，可2-3种食材混合",
    portionRange: "每餐 60-100 克",
    prohibited: ["蜂蜜", "盐", "糖", "坚果", "整颗葡萄"],
    tips: "开始引入多种蔬菜和谷物，每次新增一种食材，观察3-5天有无过敏反应。",
  },
  "10-12": {
    stage: "压磨期",
    texture: "小颗粒状，可添加软质肉类",
    portionRange: "每餐 80-120 克",
    prohibited: ["蜂蜜", "盐", "糖", "坚果"],
    tips: "可引入肉末、软熟鸡蛋黄，增加铁和锌的摄入。",
  },
  "13-24": {
    stage: "咀嚼期",
    texture: "小块状，可添加普通主食",
    portionRange: "每餐 100-150 克",
    prohibited: ["蜂蜜", "过多盐", "过多糖"],
    tips: "过渡到家庭食物，但保持少盐少糖，避免调味品刺激。",
  },
  "25-36": {
    stage: "家庭小正餐",
    texture: "接近成人饮食，少盐少糖",
    portionRange: "每餐 120-180 克",
    prohibited: ["蜂蜜（1岁前）", "刺激性调味品", "高钠加工食品"],
    tips: "可逐步适应家庭饮食，注意饮食多样化，培养良好进食习惯。",
  },
};

export function registerGetFeedingGuide(server: McpServer, _userId: string) {
  server.registerTool(
    "get_feeding_guide",
    {
      description: "获取指定月龄宝宝的辅食喂养指南，包括推荐食物质地、用量范围、禁止食物和注意事项。",
      inputSchema: {
        ageMonths: z.number().int().min(0).max(36).describe("宝宝月龄（0-36个月）"),
      },
    },
    async ({ ageMonths }) => {
      let guideKey = "0-6";
      if (ageMonths >= 7 && ageMonths <= 9) guideKey = "7-9";
      else if (ageMonths >= 10 && ageMonths <= 12) guideKey = "10-12";
      else if (ageMonths >= 13 && ageMonths <= 24) guideKey = "13-24";
      else if (ageMonths >= 25) guideKey = "25-36";

      const guide = FEEDING_GUIDE[guideKey];
      return {
        content: [
          {
            type: "text" as const,
            text: JSON.stringify({ ageMonths, ageRange: guideKey, ...guide }, null, 2),
          },
        ],
      };
    }
  );
}
