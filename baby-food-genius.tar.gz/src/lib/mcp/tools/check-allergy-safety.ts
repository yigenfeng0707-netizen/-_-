// src/lib/mcp/tools/check-allergy-safety.ts
// MCP tool: check_allergy_safety — 检查食材是否适合指定月龄及过敏宝宝

import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";

const HIGH_RISK_ALLERGENS: Record<string, string[]> = {
  "牛奶": ["奶酪", "酸奶", "黄油", "奶油", "乳清", "酪蛋白", "乳糖"],
  "鸡蛋": ["蛋白", "蛋黄", "蛋液", "蛋壳粉"],
  "花生": ["花生酱", "花生油（冷榨）", "花生粉"],
  "海鲜": ["虾", "蟹", "贝类", "鱿鱼", "章鱼", "海带（碘）", "鲑鱼", "金枪鱼"],
  "小麦": ["面粉", "面包", "饺子皮", "馒头", "麦片", "燕麦（交叉污染）"],
  "大豆": ["豆腐", "豆浆", "豆油", "酱油", "豆豉", "纳豆"],
};

const AGE_RESTRICTED_FOODS: Record<number, string[]> = {
  0: ["蜂蜜", "牛奶（直接饮用）", "坚果", "海鲜", "盐", "糖", "鸡蛋", "花生"],
  4: ["蜂蜜", "坚果", "整颗葡萄", "生胡萝卜", "大块水果"],
  7: ["蜂蜜", "坚果（整颗）", "大块硬质食物"],
  13: ["蜂蜜"],
};

export function registerCheckAllergySafety(server: McpServer, _userId: string) {
  server.registerTool(
    "check_allergy_safety",
    {
      description: "检查某种食材对特定月龄宝宝是否安全，以及是否与已知过敏原相关。",
      inputSchema: {
        ingredient: z.string().describe("要检查的食材名称"),
        ageMonths: z.number().int().min(0).max(36).describe("宝宝月龄"),
        knownAllergies: z
          .array(z.string())
          .optional()
          .describe("已知过敏原列表"),
      },
    },
    async ({ ingredient, ageMonths, knownAllergies }) => {
      const warnings: string[] = [];
      let safe = true;

      // 检查过敏原
      const allergies = knownAllergies || [];
      for (const allergen of allergies) {
        const derivatives = HIGH_RISK_ALLERGENS[allergen] || [];
        if (
          ingredient.includes(allergen) ||
          derivatives.some((d) => ingredient.includes(d))
        ) {
          warnings.push(`⚠️ "${ingredient}" 与已知过敏原 "${allergen}" 相关，建议严格避免`);
          safe = false;
        }
      }

      // 检查月龄限制
      let maxRestrictedAge = 0;
      for (const ageKey of Object.keys(AGE_RESTRICTED_FOODS).map(Number).sort((a, b) => b - a)) {
        if (ageMonths < ageKey) {
          maxRestrictedAge = ageKey;
        }
      }
      const restrictedFoods = AGE_RESTRICTED_FOODS[maxRestrictedAge] || [];
      if (restrictedFoods.some((f) => ingredient.includes(f))) {
        warnings.push(`⚠️ "${ingredient}" 不适合 ${ageMonths} 个月宝宝，建议等到月龄更大后再引入`);
        safe = false;
      }

      // 特殊检查
      if (ageMonths < 12 && ingredient.includes("蜂蜜")) {
        warnings.push("🚨 蜂蜜含肉毒杆菌孢子，1岁以下严禁食用");
        safe = false;
      }
      if (ageMonths < 6 && ingredient !== "母乳" && ingredient !== "配方奶") {
        warnings.push(`⚠️ 6个月以前建议纯母乳或配方奶喂养，"${ingredient}" 不适合添加`);
        safe = false;
      }

      return {
        content: [
          {
            type: "text" as const,
            text: JSON.stringify({
              ingredient,
              ageMonths,
              safe,
              warnings,
              recommendation: safe
                ? `✅ "${ingredient}" 对 ${ageMonths} 个月宝宝安全`
                : `❌ "${ingredient}" 存在安全风险，请注意上述警告`,
            }, null, 2),
          },
        ],
      };
    }
  );
}
