import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { registerGenerateRecipe } from "./tools/generate-recipe";
import { registerGetFeedingGuide } from "./tools/get-feeding-guide";
import { registerCheckAllergySafety } from "./tools/check-allergy-safety";

export function buildMcpServer(userId: string): McpServer {
  const server = new McpServer({
    name: "baby-food-genius",
    version: "1.0.0",
  });

  registerGenerateRecipe(server, userId);
  registerGetFeedingGuide(server, userId);
  registerCheckAllergySafety(server, userId);

  return server;
}
